import time

from selenium import webdriver


# Set up the WebDriver
driver = webdriver.Chrome()
driver.get(r'
