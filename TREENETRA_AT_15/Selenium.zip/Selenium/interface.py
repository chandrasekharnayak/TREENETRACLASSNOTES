from abc import ABC,abstractmethod

interface --- kuch specific method (work like a class)
in interface many class and methods also present.