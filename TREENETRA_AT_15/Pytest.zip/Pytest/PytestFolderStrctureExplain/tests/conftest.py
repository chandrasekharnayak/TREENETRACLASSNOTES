#common fixture file
#Common configuration