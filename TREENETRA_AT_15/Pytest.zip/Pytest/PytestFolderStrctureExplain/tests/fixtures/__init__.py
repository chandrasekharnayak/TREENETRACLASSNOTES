#precondition(setup) and postcondition(teardown)

'''
setup :- before the  testcase as per the requirements, what ever functionality is needed it's known as setup.'''

# dashboard --- validation ---- start(login)-- precondition

# dashboard --- logout --- postcondition