def addition(a,b):
    return a+b

def substraction(a,b):
    return a-b


def multiplication(a,b):
    return a*b

def division(a,b):
    return a/b

def power(a,b):
    return a**b


'''
go test directory
pytest ---- all test file execute
pytest test_file.py --- perticular test file run
pytest test_file.py -v -s ---


-v :- verbous --- find test case and percentage
-s :- each file percentage '''

'''
basic manul test
framrwork folder st.
test directory --- test case-- SRS
'''