'''var = open('/Users/macos/Desktop/XpsBackup/TREENETRA/Treenetra_class_notes/TREENETRA_AT-5/class_1_2_python_introduction.txt','r')

data = var.read()
print(data)'''

# file = open('treenetra.txt','r')
'''
read method, read the file contains from core as string.
if the file is not thier, then its return no such file or directory on File NotFoundError.
each and every file come from in python as string, every line using \n for create it.
read()
read(n)
readline()
readline()
'''



'''data = file.read(100)
print(data)'''

'''data = file.readline()
print(data)

data1 = file.readline()
print(data1)

data2 = file.readline()
print(data2)'''

# data = file.readlines()
# print(data)
# print(data[1])

'''for i in data:
    print(i)
'''
# print("qwerty \"poiuy")

'''there is a file many lines
open a file, read the last line of this file'''

'''file = open('treenetra.txt','r')

data = file.readlines()
print(data[-1])'''

# i want the check the data, in mid position list 'Kureshi' is avl or not

'''file = open('name.txt','r')
data = file.readlines()
mid = (len(data)//2)+1

if 'Kureshi' == data[ mid-1][:-1]:
    print('Kureshi is avl')
else:
    print('Kureshi is not avl')'''

#there is a file, file have 20 names line by line, print those name whose first char of the name is starts from A and position