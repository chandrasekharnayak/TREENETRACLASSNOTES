from django.shortcuts import render
from django.http import HttpResponse
from django.contrib.auth.models import User
from django.contrib import messages

# Create your views here.

def signup_view(request):
    if request.method =="POST":
        username = request.POST["username"]
        email = request.POST["email"]
        password = request.POST["password"]
        confirm_password = request.POST["confirm_password"]

        if password == confirm_password:
            if User.objects.filter(username=username).exits():
                messages.error(request,'Username already exits')
            else:
                user = User.objects.create_user(username=username,email=email,password=password)
                user.save()
                messages.success(request,'Account created successfully')
                return 'login'
        else:
            messages.error(request,'Password do not match')
    return render(request,'signup.html')

'''#signup --- user-- ui -- data send ---post
username
email
password
confirmpassword

username is not exits
'''

def HTTP--- view ()


