var = open('rough.txt', 'r')
# read_all_data = var.read()
# print(type(read_all_data))

read_line_by_line_data = var.readlines()
print(read_line_by_line_data)