data = [
    {'id': 1,
     'name': 'Wireless Mouse',
     'category': 'Electronics',
     'price': 25.99, 'stock': 150,
     'description': 'A smooth and responsive wireless mouse with ergonomic design.'},
    {'id': 2,
     'name': 'Bluetooth Speaker',
     'category': 'Electronics',
     'price': 49.99,
     'stock': 80,
     'description': 'Portable Bluetooth speaker with great sound quality.'}
    ]
