import json
import csv

from jinja2.utils import open_if_exists

#json file handleing

with open('reqres.json','r') as json_file:
    json_reader = json_file.read()
    json_data = json.loads(json_reader)


#columns creation
json_clms = list(json_data['data'][0].keys())

# rows
json_rows = []

# rows creation
for i in json_data['data']:
    json_rows.append(list(i.values()))

#csv file creation
with open('json_data_csv.csv','a') as csv_file:
    writer = csv.writer(csv_file)
    writer.writerow(json_clms)
    writer.writerows(json_rows)


#csv file read

with open('json_data_csv.csv','r') as csv_read:
    reader = csv.reader(csv_read)
    for i in reader:
        print(i)